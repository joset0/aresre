# Atajo de iOS «Enviar a ARES» (versión para la app del icono)

El atajo copia el texto del anuncio y abre ARES. En ARES pulsas «Analizar anuncio copiado»
y se rellenan precio, metros, habitaciones, baños y planta. Así todo queda guardado en la
misma ARES (la del icono de la pantalla de inicio).

## Acciones del atajo (en este orden)

1. Recibir «Apps y 18 más» de Hoja para compartir (viene sola al activar «Mostrar en la hoja de compartir»).
2. Ejecutar JavaScript en página web — sobre «Entrada de atajo» — con este código:

   var t = (document.body.innerText || "").replace(/\s+/g, " ").slice(0, 3500);
   completion(t);

3. Copiar al portapapeles (búscala como «Copiar»). Sin escribir nada: coge el resultado del JavaScript.
4. Abrir app → elige ARES si aparece en la lista. Si no aparece, sustitúyela por
   «Mostrar notificación» con el texto «Abre ARES y pulsa Analizar anuncio copiado».

## Uso

Safari → Compartir → Enviar a ARES → se abre ARES → pulsa «Analizar anuncio copiado» (en Inicio)
o «Pegar lo copiado» (en la Calculadora). Si el iPhone pregunta si permites pegar, pulsa Permitir.
