#!/usr/bin/env bash
# ARES · Calculadora inmobiliaria — instalador / actualizador
# Uso:  sudo bash /tmp/ares/instalar.sh
# Qué hace: copia la app estática a /opt/ares/web y añade el dominio a Caddy.
# Qué NO hace: no toca /opt/livanza, ni su base de datos, ni el servicio del ERP,
#              ni ningún puerto. ARES no tiene backend ni guarda nada en el servidor.
set -euo pipefail

DOMINIO="ares.atlasrealstates.com"
ORIGEN="$(cd "$(dirname "$0")" && pwd)"
DESTINO="/opt/ares"
CADDYFILE="/etc/caddy/Caddyfile"

echo "== ARES · instalación en $DESTINO =="

if [ "$(id -u)" -ne 0 ]; then echo "Ejecútalo con sudo: sudo bash $0"; exit 1; fi
if ! command -v caddy >/dev/null 2>&1; then
  echo "Este servidor no tiene Caddy. Dime qué servidor web usa (nginx, apache…) y te preparo la configuración."; exit 1
fi
if [ ! -f "$CADDYFILE" ]; then
  CADDYFILE="$(find /etc /opt -maxdepth 4 -name Caddyfile 2>/dev/null | head -1 || true)"
  [ -n "$CADDYFILE" ] || { echo "No encuentro el Caddyfile. Ejecuta:  sudo find / -name Caddyfile 2>/dev/null   y mándame el resultado."; exit 1; }
fi
echo "Caddyfile: $CADDYFILE"

# 1) Copiar la app (solo la carpeta de ARES)
mkdir -p "$DESTINO"
rm -rf "$DESTINO/web.nuevo"
cp -r "$ORIGEN/web" "$DESTINO/web.nuevo"
[ -d "$DESTINO/web" ] && { rm -rf "$DESTINO/web.anterior"; mv "$DESTINO/web" "$DESTINO/web.anterior"; }
mv "$DESTINO/web.nuevo" "$DESTINO/web"
cp "$ORIGEN/ATAJO-IOS.md" "$DESTINO/" 2>/dev/null || true
chmod -R a+rX "$DESTINO"
echo "App copiada en $DESTINO/web"

# 2) Añadir el dominio a Caddy (solo la primera vez)
if grep -q "$DOMINIO" "$CADDYFILE"; then
  echo "Caddy ya conocía $DOMINIO — no se toca la configuración."
else
  cp "$CADDYFILE" "$CADDYFILE.antes-de-ares-$(date +%Y%m%d-%H%M%S)"
  printf '\n' >> "$CADDYFILE"
  cat "$ORIGEN/caddy/ares.caddy" >> "$CADDYFILE"
  echo "Bloque de $DOMINIO añadido al Caddyfile (copia de seguridad guardada al lado)."
fi

# 3) Validar y recargar Caddy sin cortar nada
caddy validate --config "$CADDYFILE" --adapter caddyfile >/dev/null
if systemctl is-active --quiet caddy; then
  systemctl reload caddy
  echo "Caddy recargado."
else
  echo "AVISO: el servicio 'caddy' no está activo como systemd. Si Caddy va en Docker, dímelo y ajusto el paso."
fi

# 4) Comprobar DNS
echo
if getent hosts "$DOMINIO" >/dev/null 2>&1; then
  echo "DNS OK: $DOMINIO → $(getent hosts "$DOMINIO" | awk '{print $1}' | head -1)"
  echo "Abre en el móvil: https://$DOMINIO  (el certificado tarda 10-60 s la primera vez)"
else
  echo "DNS todavía no resuelve $DOMINIO. Es normal si acabas de crear el registro: espera 5-30 min."
  echo "Caddy pedirá el certificado solo en cuanto el DNS apunte al servidor."
fi
echo "== Listo =="
