# ARES 1.0.2 — Instalación en el servidor de Livanza

ARES es una app estática: solo archivos que Caddy sirve. **No tiene base de datos, no
guarda nada en el servidor y no toca /opt/livanza ni el servicio del ERP.** Vive en su
propia carpeta (/opt/ares) y su propio dominio (ares.atlasrealstates.com). Tus
simulaciones se guardan solo en tu iPhone.

## PASO 1 — Apuntar el dominio (5 minutos, desde el móvil o el PC)

1. Entra en el panel donde compraste **atlasrealstates.com** (en GoDaddy: Mi cuenta →
   Mis productos → junto al dominio, pulsa **DNS**).
2. Pulsa **Añadir registro** (o «Agregar nuevo registro»).
3. Rellena exactamente:
   - Tipo: **A**
   - Nombre (o Host): **ares**
   - Valor (o «Apunta a»): **187.33.158.203**
   - TTL: déjalo como está (o 600 segundos)
4. Guarda. Suele funcionar en 5-30 minutos.

## PASO 2 — Subir el paquete al servidor (desde el PC de la oficina)

1. Abre **WinSCP** y conéctate al servidor de Livanza (187.33.158.203, el mismo acceso
   que usas para el ERP).
2. En la parte derecha, entra en la carpeta **/tmp**.
3. Arrastra el archivo **ares-1.0.2.zip** desde tu PC a /tmp.

## PASO 3 — Instalar (2 minutos)

1. Abre la consola SSH del servidor (desde el menú «Herramientas del servidor» de tu
   escritorio o con el cliente SSH).
2. Copia y pega estas tres líneas, una a una, pulsando Intro tras cada una:

```
cd /tmp && rm -rf /tmp/ares && unzip -qo ares-1.0.2.zip
sudo bash /tmp/ares/instalar.sh
```

3. Debe terminar con **== Listo ==**. Si el DNS del paso 1 todavía no ha llegado, dirá
   «DNS todavía no resuelve»: no pasa nada, espera y abre la dirección más tarde.

## PASO 4 — Ponerla en el iPhone como app

1. Abre **Safari** y entra en **https://ares.atlasrealstates.com**
2. Pulsa el botón **Compartir** (cuadrado con flecha).
3. Baja y pulsa **Añadir a pantalla de inicio** → **Añadir**.
4. Aparece el icono dorado de ARES; ábrela desde ahí (pantalla completa, sin barras).

## PASO 5 — Crear el atajo «Enviar a ARES»

Sigue el archivo **ATAJO-IOS.md** (3 minutos, una sola vez).

## Actualizar en el futuro

Sube el nuevo zip a /tmp y repite el PASO 3 con el nombre de la versión nueva. El
instalador guarda la versión anterior en /opt/ares/web.anterior.

## Si algo falla

- «Este servidor no tiene Caddy» o «No encuentro el Caddyfile»: mándame el mensaje tal
  cual y te doy el paso alternativo.
- Sale la página pero sin diseño o en blanco: recarga con Safari (no desde el icono),
  y si sigue, mándame captura.
