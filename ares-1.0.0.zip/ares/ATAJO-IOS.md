# Atajo de iOS «Enviar a ARES»

Con este atajo abres un anuncio en Safari (Idealista, Fotocasa, pisos.com…),
pulsas Compartir → «Enviar a ARES» y la calculadora se abre con el anuncio ya leído.
Funciona con Idealista porque el texto lo coge de tu propio Safari, no de un servidor.

Se crea una sola vez, en unos 3 minutos, desde el iPhone.

## Paso a paso

1. Abre la app **Atajos** del iPhone (viene instalada; si no la ves, búscala en la App Store, es de Apple y gratis).
2. Pulsa **+** arriba a la derecha para crear un atajo nuevo.
3. Pulsa el nombre de arriba («Nuevo atajo 1») → **Renombrar** → escribe **Enviar a ARES**.
4. Pulsa el icono de información **(i)** de abajo (o «Detalles» en el menú del nombre) y activa **Mostrar en la hoja de compartir**. Luego pulsa **Listo**.
5. Ahora vamos a añadir las acciones, una debajo de otra. Para cada una, pulsa **Añadir acción** (o la lupa de búsqueda de abajo), escribe el nombre y tócala:

   **Acción 1 — «Ejecutar JavaScript en página web»**
   - Búscala como «JavaScript». Al añadirla te preguntará sobre qué: elige **Entrada del atajo**.
   - Borra el código de ejemplo que trae y pega exactamente esto:

   ```
   var t = document.body.innerText || "";
   completion(t.replace(/\s+/g, " ").slice(0, 3500));
   ```

   **Acción 2 — «Codificar URL»**
   - Búscala como «Codificar». Debe aplicarse al resultado de la acción anterior
     (aparece automáticamente como «Resultado de JavaScript»). Déjala en **Codificar**.

   **Acción 3 — «Abrir URL»**
   - Búscala como «Abrir URL». En el campo de la dirección escribe:

   ```
   https://ares.atlasrealstates.com/?anuncio=
   ```

   y, justo después del signo «=», pulsa sobre el campo, elige **Seleccionar variable**
   y toca **Texto codificado en URL** (el resultado de la acción 2).
   Debe quedar: `https://ares.atlasrealstates.com/?anuncio=` seguido de la pastilla azul de la variable.

6. Pulsa **Listo** arriba a la derecha.
7. Si al ejecutarlo por primera vez Atajos pide permiso para «ejecutar JavaScript en Safari»
   o para abrir la dirección, pulsa **Permitir siempre**.
   Si no aparece, ve a Ajustes → Atajos → Avanzado y activa **Permitir ejecutar scripts**.

## Cómo se usa

1. Abre el anuncio en **Safari** (tiene que ser Safari, no la app de Idealista ni Chrome).
2. Pulsa el botón **Compartir** (el cuadrado con la flecha hacia arriba).
3. En la lista, toca **Enviar a ARES** (la primera vez puede estar abajo del todo; puedes
   subirlo con «Editar acciones»).
4. Se abre ARES con precio, metros, habitaciones, baños y planta ya leídos. Completa el
   alquiler previsto y pulsa **Calcular rentabilidad**.

Si el anuncio se abre en la app de Idealista en lugar de en Safari, usa dentro de la app
su botón de compartir → **Copiar enlace**, pega el enlace en Safari y ya desde ahí, Compartir → Enviar a ARES.
